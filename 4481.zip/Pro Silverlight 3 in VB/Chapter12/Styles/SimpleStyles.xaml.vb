Partial Public Class SimpleStyles
    Inherits UserControl

    Public Sub New()
        InitializeComponent()
    End Sub

End Class
