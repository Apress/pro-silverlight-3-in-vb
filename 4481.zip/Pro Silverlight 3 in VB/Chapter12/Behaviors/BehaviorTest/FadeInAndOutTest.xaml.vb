﻿Partial Public Class FadeInAndOutTest
    Inherits UserControl

    Public Sub New 
        InitializeComponent()
    End Sub

End Class
