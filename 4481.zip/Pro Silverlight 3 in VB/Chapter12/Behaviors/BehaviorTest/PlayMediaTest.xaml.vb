﻿Partial Public Class PlayMediaTest
    Inherits UserControl

    Public Sub New 
        InitializeComponent()
    End Sub

End Class
