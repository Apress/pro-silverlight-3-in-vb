﻿Partial Public Class DragInCanvasTest
    Inherits UserControl

    Public Sub New 
        InitializeComponent()
    End Sub

End Class
