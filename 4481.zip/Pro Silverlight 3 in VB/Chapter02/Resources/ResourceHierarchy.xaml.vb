﻿Partial Public Class ResourceHierarchy
    Inherits UserControl

    Public Sub New 
        InitializeComponent()
    End Sub

End Class
