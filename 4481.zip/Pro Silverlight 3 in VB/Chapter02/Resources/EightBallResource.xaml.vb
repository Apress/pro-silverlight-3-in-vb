﻿Partial Public Class EightBallResource
    Inherits UserControl

    Public Sub New 
        InitializeComponent()
    End Sub

End Class
