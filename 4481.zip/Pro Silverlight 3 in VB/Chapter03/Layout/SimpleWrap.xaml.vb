﻿Partial Public Class SimpleWrap
    Inherits UserControl

    Public Sub New 
        InitializeComponent()
    End Sub

End Class
