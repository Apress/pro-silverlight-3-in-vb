Partial Public Class SimpleStack
    Inherits UserControl
    Public Sub New()
        InitializeComponent()
    End Sub
End Class
