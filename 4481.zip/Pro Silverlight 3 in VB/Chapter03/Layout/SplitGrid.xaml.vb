Partial Public Class SplitGrid
    Inherits UserControl
    Public Sub New()
        InitializeComponent()
    End Sub
End Class
