Partial Public Class NestedContainers
    Inherits UserControl
    Public Sub New()
        InitializeComponent()
    End Sub
End Class
