
The DataBinding project is set up to use a "simulated" approach that retrieves data from an XML file.

Alternately, you can install the full SQL Server database with the data using the store.sql script. Then, remove or comment out the code in the StoreDbFileBased.vb file and uncomment the code in the StoreDbDatabase.vb file.
