Partial Public Class WrapPanelTest
    Inherits UserControl
    Public Sub New()
        InitializeComponent()
    End Sub
End Class
