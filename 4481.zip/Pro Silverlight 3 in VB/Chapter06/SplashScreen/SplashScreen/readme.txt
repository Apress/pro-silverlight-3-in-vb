﻿To try out this example, first add several large files (for example, 10 files that are 5 MB each) to the
Silverlight project. Set the Build Action of each one to Resource so that it will be embedded in the compiled
.XAP file. This will slow down the download enough that you will see the splash screen.
You may also need to make changes to the Silverlight project or forcibly recompile it each time you run it.