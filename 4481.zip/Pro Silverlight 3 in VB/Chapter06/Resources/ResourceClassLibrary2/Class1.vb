﻿Public Class ClassLibraryUtil
    Public Function DoSomething() As String
        Return "Test successful."
    End Function
End Class