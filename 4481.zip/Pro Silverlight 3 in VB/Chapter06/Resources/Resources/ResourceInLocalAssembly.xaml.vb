Partial Public Class ResourceInLocalAssembly
    Inherits UserControl
    Public Sub New()
        InitializeComponent()
    End Sub
End Class
