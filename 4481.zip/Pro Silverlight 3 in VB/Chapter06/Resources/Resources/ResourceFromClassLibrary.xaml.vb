Partial Public Class ResourceFromClassLibrary
    Inherits UserControl
    Public Sub New()
        InitializeComponent()
    End Sub
End Class
