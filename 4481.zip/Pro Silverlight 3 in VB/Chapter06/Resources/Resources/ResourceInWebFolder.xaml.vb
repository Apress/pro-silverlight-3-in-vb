Partial Public Class ResourceInWebFolder
    Inherits UserControl
    Public Sub New()
        InitializeComponent()
    End Sub
End Class
