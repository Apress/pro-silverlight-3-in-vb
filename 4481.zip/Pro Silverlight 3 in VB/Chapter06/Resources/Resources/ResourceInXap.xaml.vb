Partial Public Class ResourceInXap
    Inherits UserControl
    Public Sub New()
        InitializeComponent()
    End Sub
End Class
