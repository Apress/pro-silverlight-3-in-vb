Partial Public Class SimpleTreeView
    Inherits UserControl
    Public Sub New()
        InitializeComponent()
    End Sub
End Class
