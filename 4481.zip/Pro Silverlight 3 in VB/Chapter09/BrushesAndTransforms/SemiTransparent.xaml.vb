﻿Partial Public Class SemiTransparent
    Inherits UserControl

    Public Sub New 
        InitializeComponent()
    End Sub

End Class
