﻿Partial Public Class Effects
    Inherits UserControl

    Public Sub New 
        InitializeComponent()
    End Sub

End Class
