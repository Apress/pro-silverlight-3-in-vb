Partial Public Class Page2
    Inherits UserControl
    Public Sub New()
        InitializeComponent()
    End Sub
End Class
