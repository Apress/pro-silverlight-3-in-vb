Partial Public Class Page1
    Inherits UserControl
    Public Sub New()
        InitializeComponent()
    End Sub
End Class
