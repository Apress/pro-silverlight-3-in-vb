﻿Partial Public Class ScaleShapes
    Inherits UserControl

    Public Sub New 
        InitializeComponent()
    End Sub

End Class
