﻿Partial Public Class DashedLines
    Inherits UserControl

    Public Sub New 
        InitializeComponent()
    End Sub

End Class
