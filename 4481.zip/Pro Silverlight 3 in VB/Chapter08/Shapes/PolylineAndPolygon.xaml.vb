﻿Partial Public Class PolylineAndPolygon
    Inherits UserControl

    Public Sub New 
        InitializeComponent()
    End Sub

End Class
