﻿Partial Public Class SilverlightClipArt
    Inherits UserControl

    Public Sub New 
        InitializeComponent()
    End Sub

End Class
