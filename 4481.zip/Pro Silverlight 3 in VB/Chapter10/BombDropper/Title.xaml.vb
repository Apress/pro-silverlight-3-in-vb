Partial Public Class Title
    Inherits UserControl
    Public Sub New()
        InitializeComponent()
    End Sub
End Class
