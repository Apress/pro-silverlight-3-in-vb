﻿Partial Public Class TemplateParts
    Inherits UserControl

    Public Sub New 
        InitializeComponent()
    End Sub

End Class
