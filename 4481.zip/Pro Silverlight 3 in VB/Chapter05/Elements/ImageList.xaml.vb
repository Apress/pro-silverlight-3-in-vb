Partial Public Class ImageList
    Inherits UserControl
    Public Sub New()
        InitializeComponent()
    End Sub
End Class
