Partial Public Class ImageSizing
    Inherits UserControl
    Public Sub New()
        InitializeComponent()
    End Sub
End Class
