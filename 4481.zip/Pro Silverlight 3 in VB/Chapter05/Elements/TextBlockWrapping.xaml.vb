Partial Public Class TextBlockWrapping
    Inherits UserControl
    Public Sub New()
        InitializeComponent()
    End Sub
End Class
