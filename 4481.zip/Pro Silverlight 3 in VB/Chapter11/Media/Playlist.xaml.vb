Partial Public Class Playlist
    Inherits UserControl
    Public Sub New()
        InitializeComponent()
    End Sub


End Class
